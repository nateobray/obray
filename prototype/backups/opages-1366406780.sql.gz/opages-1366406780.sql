-- MySQL dump 10.13  Distrib 5.5.29, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: prototype
-- ------------------------------------------------------
-- Server version	5.5.29-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `opages`
--

DROP TABLE IF EXISTS `opages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opages` (
  `opage_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `opage_title` varchar(255) DEFAULT NULL,
  `opage_description` text,
  `opage_keywords` text,
  `opage_head` text,
  `opage_published` tinyint(1) DEFAULT NULL,
  `opage_permission_level` int(11) DEFAULT NULL,
  `opage_secured` tinyint(1) DEFAULT NULL,
  `opage_template` varchar(75) DEFAULT NULL,
  `opage_layout` varchar(75) DEFAULT NULL,
  `opage_deletable` tinyint(1) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `order_variable` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `OCDT` datetime DEFAULT NULL,
  `OCU` int(10) unsigned DEFAULT NULL,
  `OMDT` datetime DEFAULT NULL,
  `OMU` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`opage_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opages`
--

LOCK TABLES `opages` WRITE;
/*!40000 ALTER TABLE `opages` DISABLE KEYS */;
INSERT INTO `opages` VALUES (1,'Home',NULL,NULL,NULL,0,100,0,'default','default',0,'',12,0,'2013-04-18 09:23:50',0,NULL,NULL),(14,'asdf',NULL,NULL,NULL,0,100,0,'default','default',0,'asdf',7,13,'2013-04-18 09:54:41',0,NULL,NULL),(13,'asdf',NULL,NULL,NULL,0,100,0,'default','default',0,'asdf',1,1,'2013-04-18 09:46:45',0,NULL,NULL);
/*!40000 ALTER TABLE `opages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-19 15:26:20
